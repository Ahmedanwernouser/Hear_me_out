import 'dart:ui';

const kMainColor = Color(4283518970);
const kSecondColor = Color(4282498717);
const kSilverColor = Color(4288253858);
