const String USERS_COLLECTION_NAME = 'users';
const String USERS_USERNAME = 'name';
const String USERS_EMAIL = 'email';

const String CHATROOM_COLLECTION_NAME = 'chatRoom';
const String CHATROOM_USER = 'users';
const String CHATROOM_ID = 'chatRoomId';

const String CHATS_COLLECTION_NAME = 'chats';
const String CHATS_MESSAGE = 'message';
const String CHATS_SEND_BY = 'SendBy';
const String CHATS_TIME = 'time';
