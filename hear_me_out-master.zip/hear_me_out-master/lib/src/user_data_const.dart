class Constants {
  static String userName = '';
}
