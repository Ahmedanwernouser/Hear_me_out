// import 'package:camera/camera.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
//
// class CameraProvider extends ChangeNotifier {
//   List<CameraDescription> cameras;
//
//   addCamera(camera) {
//     cameras = camera;
//     notifyListeners();
//   }
// }
