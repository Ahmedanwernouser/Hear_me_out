class AppUser {
  String userId;

  AppUser({this.userId});
}
