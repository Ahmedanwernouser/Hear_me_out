package com.example.hear_me_out

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
